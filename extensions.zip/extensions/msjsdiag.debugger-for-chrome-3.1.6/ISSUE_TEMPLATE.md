<!-- Please see the debugging tips in the README.md before filing an issue. Especially the tip about using the `.scripts` command. -->

- VS Code Version:

Steps to reproduce:

1.
2.