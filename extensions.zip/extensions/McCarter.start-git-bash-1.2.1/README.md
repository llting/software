# README

This small Visual Studio Code extension adds two "bash" commands to VSCode that allow you to start git-bash, either in the folder of the current file or in the workspace's root folder.

Plugin provides two commands:

* `bash` will open bash in your current file's directory.
* `bash in workspace` will open bash always in the root workspace directory, despite what file is opened.

Just press F1 and then type any of above commands to start git-bash.exe.

**Note that you will need to have git-bash.exe on the environment path.**

**Enjoy!**
