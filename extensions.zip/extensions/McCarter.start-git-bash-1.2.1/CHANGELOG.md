## Version 1.2.0
*  Added a second command to open bash in the root directory of the workspace, even if a file is currently open.

    Thanks to [LaChRiZ](https://github.com/LaChRiZ) for the logo

    Thanks to [mlewand](https://github.com/mlewand) for the workspace root command addition

## Version 1.1.0
* Updated so that if you have a file open it will open git-bash in the folder of the file,
but if there's no folder it will still default to the workspace root folder.
Thanks to [Leo](https://github.com/leotm) for the idea and pull request!  :-)

## Version 1.0.4
* Improved error checking when git-bash isn't on the path
* No longer opens an informational message when it opens git-bash (that you then have to close each time, which is annoying).
