We use [GitHub's Releases feature](https://github.com/blog/1547-release-your-software) for changelogs.

See [the Releases section of our GitHub project](https://github.com/mrmlnc/vscode-less/releases) for changelogs for each release version of this plugin.
