"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.console = null;
function create(nConsole) {
    exports.console = nConsole;
}
exports.create = create;
//# sourceMappingURL=index.js.map